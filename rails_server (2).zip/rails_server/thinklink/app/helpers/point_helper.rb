module PointHelper
end
