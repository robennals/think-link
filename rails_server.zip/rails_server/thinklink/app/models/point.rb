class Point < ActiveRecord::Base
	has_many :snippets
#	belongs_to :user
	
	validates_presence_of :txt
end
