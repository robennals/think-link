class MainController < ApplicationController
	include MainHelper

  def register
    if request.post?
      @user = User.new params[:user]
      if @user.save
        flash[:info] = 'You are registered now'
      end
    end
  end
  
  def login
  	if request.post?
  	  if auth_correct?(params[:email],params[:password])
			   cookies[:email] = params[:email]
			   cookies[:password] = params[:password]					   
	       redirect_to :controller => 'panel', :action => 'secret'
			else 
			   @auth_error = 'Wrong username or password'
			end
  	end
	end
	
	def showuser
		check_auth
		@email = cookies[:email]
		@password = cookies[:password]
	end

end
