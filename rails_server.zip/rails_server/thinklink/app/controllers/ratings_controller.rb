class RatingsController < ApplicationController
end
