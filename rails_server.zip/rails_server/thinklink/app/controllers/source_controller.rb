class SourceController < ApplicationController
	scaffold:source
end
