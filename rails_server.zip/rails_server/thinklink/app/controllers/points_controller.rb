require 'ruby-debug'

class PointsController < ApplicationController
	include MainHelper
	
	def index
		@points = Point.find(:all)
		emit(@points)
	end
	def show
		@point = Point.find(params[:id])
		emit(@point,{:only => [:txt], :include => :snippets, :methods => :avgrating})
	end
	def snippets
		@point = Point.find(params[:id])
		@snippets = @point.snippets
		emit(@snippets,{:methods => :avgrating})
	end
	def new
		@point = Point.new
	end
	def create
		@point = Point.new(params[:point])
    respond_to do |format|
      if @point.save
        flash[:notice] = 'Source was successfully created.'
        format.html { redirect_to(@point) }
        format.xml  { render :xml => @point, :status => :created, :location => @point }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @point.errors, :status => :unprocessable_entity }
      end
    end
  end
	def edit
	end
	def update
	end
	def delete
	end
end

def emit(obj,opts = {})
	respond_to do |format|
		format.html {}
		format.xml { render :xml => obj.to_xml(opts)}
		format.json { render :text => obj.to_json(opts)}
		format.js {render :text => "tl_callback(" + obj.to_json(opts) + ")"}
	end
end
