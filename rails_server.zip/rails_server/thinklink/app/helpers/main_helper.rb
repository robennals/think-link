require 'ruby-debug'

module MainHelper
	def auth_correct?(email, password)
  	@user = User.find_by_email(email)
		if @user and @user.password == password
			return true
		else
			return false
		end
	end
	
	def check_auth(email = cookies[:email], password = cookies[:password])
		unless auth_correct?(email,password)
			flash[:error] = 'You need to be logged in to do this'
			redirect_to :controller => 'main', :action => 'login'
		end
	end
end
